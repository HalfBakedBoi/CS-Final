//Backend for the game, should include basic menu system and choice system.


#include "pch.h"
#include <iostream>
#include <windows.h>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")
using namespace std;
int MainMenu = { 0 };

void path1();

int main()
{
	system("mode con COLS=700");
	ShowWindow(GetConsoleWindow(), SW_MAXIMIZE);

	PlaySound(TEXT("great_scott.wav"), NULL, SND_FILENAME | SND_ASYNC);

	do {
		
		cout << "Please choose a number between 1-4 and 42 to quit \n";
		cin >> MainMenu;

		switch (MainMenu)
		{

		case 1:
			cout << "Path 1\n";

			path1();

			break;

		case 2:
			cout << "Path 2\n";
			break;

		case 3:
			cout << "path 3\n";
			break;

		case 4:
			cout << "path 4\n";
			MainMenu = 42;
			break;


		case 2147483647:
			cout << "Kills the loop\n";
			MainMenu = 42;
			break;

		default:
			cout << "try picking a real choice\n";
			break;
		}

	} while (MainMenu != 42);

}


void path1()
{
	
	int menu1 = { 0 };
	int Path1Choice1{0};


	cout << "Choose 1-4 Path 1 first choice\n";
	cin >> Path1Choice1;

	switch (Path1Choice1)
	{

	case 1:

		cout << "Path 1 second choice\n";
		cin >> menu1;

			switch (menu1)
			{

			case 1:
				cout << "test level 1-1\n";
				break;

			case 2:
				cout << "1 level reset\n";
				break;

			default:

				cout << "Default exit\n";
				break;

			}

		break;

	case 2:

		cout << "Path 2\n";
		break;

	case 3:
		cout << "path 3\n";
		break;

	case 4:
		cout << "path 4\n";
		break;

	default:
		cout << "try picking a real choice\n";
		break;
	}
}